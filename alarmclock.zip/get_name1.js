function get_name(username){
    var xhttp = new XMLHttpRequest();
    xhttp.open("GET", "find_name_from_username.php", false);
    xhttp.send();
    var result = xhttp.responseText;
    
    var paragraph1 = document.getElementById("statusmessage1");
    var paragraph2 = document.getElementById("statusmessage2");
    paragraph1.innerHTML = "Hi " + result + ", you might have had a connection to an infected person at the location shown in red";
    paragraph2.innerHTML = "Click on the marker to see details about the infection.";
    //alert(result);

  }