<?php
define('host', 'localhost');
define('user', 'Artur');
define('password', 'password');
define('database', 'webdev');
define('port', '3306');
?>