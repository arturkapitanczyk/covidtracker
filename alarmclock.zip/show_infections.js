//var infections = <?php echo json_encode($infections); ?>;
var infections;
function addmarkerblack(x, y){
        var map = document.getElementById("exetermap");
        var blackmarker = document.createElement("IMG");
        blackmarker.setAttribute("src", "marker_black.png");
        //blackmarker.setAttribute("align", "right");
        blackmarker.style.maxHeight = "50px";
        blackmarker.style.maxWidth = "50px";
        blackmarker.style.position = "absolute";
        var distanceleft = parseInt(map.getBoundingClientRect().left);
        var distancetop = parseInt(map.getBoundingClientRect().bottom);
        blackmarker.style.left = "" + (distanceleft + parseInt(x) - 25) + "px";
        blackmarker.style.top = "" + (distancetop  - parseInt(y) - 50) + "px";

        blackmarker.addEventListener('click', function(event){
            var map = document.getElementById("exetermap");
            var x = event.clientX - map.getBoundingClientRect().left;
            var y = map.getBoundingClientRect().bottom - event.clientY;
            alert("x: " + Math.round(x) + ", y: " + Math.round(y));
        });

        var homeseconddiv = document.getElementById("homeseconddiv");
        homeseconddiv.appendChild(blackmarker);

}

function addmarkerred(x, y){
    var map = document.getElementById("exetermap");
    var blackmarker = document.createElement("IMG");
    blackmarker.setAttribute("src", "marker_red.png");
    //blackmarker.setAttribute("align", "right");
    blackmarker.style.maxHeight = "50px";
    blackmarker.style.maxWidth = "50px";
    blackmarker.style.position = "absolute";
    var distanceleft = parseInt(map.getBoundingClientRect().left);
    var distancetop = parseInt(map.getBoundingClientRect().bottom);
    blackmarker.style.left = "" + (distanceleft + parseInt(x) - 25) + "px";
    blackmarker.style.top = "" + (distancetop  - parseInt(y) - 50) + "px";

    blackmarker.addEventListener('click', function(event){
        var map = document.getElementById("exetermap");
        var x = event.clientX - map.getBoundingClientRect().left;
        var y = map.getBoundingClientRect().bottom - event.clientY;
        alert("x: " + Math.round(x) + ", y: " + Math.round(y));
    });

    var homeseconddiv = document.getElementById("homeseconddiv");
    homeseconddiv.appendChild(blackmarker);

}

