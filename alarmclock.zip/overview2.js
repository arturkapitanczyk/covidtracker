  function deletevisit(rownumber){
    //alert(rownumber);
    var xhttp = new XMLHttpRequest();
    xhttp.open("POST", "delete_visit.php", false);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("rnumber=" + rownumber);
    var result = xhttp.responseText;
    filltable();
  }


  function filltable()
  {
    var table = document.getElementById("tableofvisits");

    var xhttp = new XMLHttpRequest();
    xhttp.open("GET", "get_all_visits.php", false);
    xhttp.send();
    var result = xhttp.responseText;
    for (var y = 1;y < table.rows.length;y++){
      table.deleteRow(1);
    }

    if (result)
      {
        var allrows = result.split(" ");
        for (var i = 0; i < allrows.length;i++){
          var allelementsinrow = allrows[i].split("T");
          var rownumber = i + 1;
          var row = table.insertRow(i + 1);
          
          var date = row.insertCell(0);
          var time = row.insertCell(1);
          var duration = row.insertCell(2);
          var x = row.insertCell(3);
          var y = row.insertCell(4);
          var button = row.insertCell(5);

          date.innerHTML = allelementsinrow[0];
          time.innerHTML = allelementsinrow[1];
          duration.innerHTML = allelementsinrow[2];
          x.innerHTML = allelementsinrow[3];
          y.innerHTML = allelementsinrow[4];
          var crossbutton = '<input type="button" onclick="deletevisit(' + allelementsinrow[5] + ')" name="remove" style="background:url(cross.png) no-repeat; min-width: 20px; min-height: 20px; background-size: 100%"></input>';
          button.innerHTML = crossbutton;
        }
        table.deleteRow(1);
      }



  }


