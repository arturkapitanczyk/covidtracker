<?php
    session_start();
    $username = $_SESSION["username"];
    require 'auth.php'; 
    $conn = mysqli_connect(host, user, password, database, port);
    if (!$conn){
        die("Connection error: " . mysqli_connect_error());
    }
    $sql = "SELECT name FROM Accounts WHERE username = '" . $username . "'";
    if (($result=mysqli_query($conn, $sql)) === false){
        die("Error2".$sql);
    }
    $name = mysqli_fetch_row($result);
    echo $name[0];
?>