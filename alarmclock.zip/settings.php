<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="settings90.css">
    </head>
    <body class="main-T">
        <div class="div-1">COVID - 19 Contact Tracing</div>
        <div class="first" >
            <div class="menucontainer">
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
                <input class="button" type="submit"  name="home" value="<?=Home?>" ><br>
                <input class="button" type="submit"  name="overview" value="<?=Overview?>" ><br>
                <input class="button" type="submit" name="addvisit" value="<?=AddVisit?>"><br>
                <input class="button" type="submit" name="report" value="<?=Report?>"><br>
                <input class="buttoncurrent" type="submit" name="settings" value="<?=Settings?>"><br><br><br><br>
                <input class="button" type="submit" name="logout" value="<?=Logout?>">
                </form>
            </div>
            <div class="div-2">
                <h2>Alert Settings</h2>
                <hr>
                <p> Here you may change the alert distance and time span for which the contact tracing will be performed.</p>
                <br><br><br><br><br>
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
                <label for="window">window</label>
                <select class="input-T" id="window" name="window">
                    <option value="1">one week</option>
                    <option value="2">two weeks</option>
                    <option value="3">three weeks</option>
                    <option value="4">four weeks</option>
                </select><br><br>
                <label for="distance">distance</label>
                <input id="distance" class="input-T" type="text" name="distance"><br><br>
                <input class="input-T" type="submit" name="reportdata" value="<?=Report?>">
                <input class="input-T" type="submit" name="cancel" value="<?=Cancel?>">
                </form>
                
                
            </div>
        <?php
            require 'auth.php';          

            $home = $_GET["home"];
                if ($home === Home){
                    header("Location: home.php");
                    exit;
                }
            $overview = $_GET["overview"];
                if ($overview === Overview){
                    header("Location: overview.php");
                    exit;
                }
            $addvisit = $_GET["addvisit"];
                if ($addvisit === AddVisit){
                    header("Location: addvisit.php");
                    exit;
                }
            $report = $_GET["report"];
                if ($report === Report){
                    header("Location: report.php");
                    exit;
                }
            $settings = $_GET["settings"];
                if ($settings === Settings){
                    header("Location: settings.php");
                    exit;
                }
            $logout = $_GET["logout"];
                if ($logout === Logout){
                    header("Location: index.php");
                    exit;
                }
            $reportdata = $_GET["reportdata"];
                if ($reportdata === Report){
                    $window = $_GET["window"];
                    $distance = $_GET["distance"];
                    $iscorrectentry = True;
                    
                    $min = 0;
                    $max = 500;
                    $distanceint = (int)$distance;
                    if(!(($min <= $distanceint) && ($distanceint <= $max))){
                        $iscorrectentry = False;
                        Header("Location: settings.php");
                        exit;
                    }

                    if($iscorrectentry){
                        setcookie("window", $window);
                        setcookie("distance", $distance);
                        Header("Location: settings.php");
                        exit;
                    }

                }
            $cancel = $_GET["cancel"];
                if ($cancel === Cancel){
                    Header("Location: settings.php");
                    exit;
                }
        ?>
    </body>
</html>