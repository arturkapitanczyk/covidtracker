<?php

    require 'auth.php'; 
    session_start();
    $username = $_SESSION["username"];
    $conn = mysqli_connect(host, user, password, database, port);
    if (!$conn){
        die("Connection error: " . mysqli_connect_error());
    }
    $sql = "SELECT date, time, duration, x, y, id from Visits WHERE username = '" . $username . "'";
    if (($result=mysqli_query($conn, $sql)) === false)
        die("Error executing " . $sql);              
    if (mysqli_num_rows($result) > 0) {
            // output data of each row
        while($row = mysqli_fetch_assoc($result)) {
            echo " " . $row["date"] . "T" . $row["time"] . "T" . $row["duration"]. "T" . $row["x"] . "T" . $row["y"] . "T" . $row["id"] . "";
        }
    } else {
        die;
      }
?>