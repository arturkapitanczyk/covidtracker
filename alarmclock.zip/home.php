
<?php
    session_start();
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="home5.css">
        <script type="text/javascript" src="get_name1.js"></script>
        <script type="text/javascript" src="show_infections.js"></script>
    </head>
    <body class="main-T">
        <div class="div-1">COVID - 19 Contact Tracing</div>
        <div class="first" >
            <div class="menucontainer">
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
                <input class="buttoncurrent" type="submit"  name="home" value="<?=Home?>" ><br>
                <input class="button" type="submit"  name="overview" value="<?=Overview?>" ><br>
                <input class="button" type="submit" name="addvisit" value="<?=AddVisit?>"><br>
                <input class="button" type="submit" name="report" value="<?=Report?>"><br>
                <input class="button" type="submit" name="settings" value="<?=Settings?>"><br><br><br><br>
                <input class="button" type="submit" name="logout" value="<?=Logout?>">
                </form>
            </div>
            <div id="homeseconddiv"class="div-2">
                <h2>Status</h2>
                <hr>
                <img class="exetermap" src="exetermap.jpg" align="right" id="exetermap">
                    <p style="font-family: 'Times New Roman', Times, serif" id="statusmessage1" class="statusmessage"> yo1</p>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <p style='font-family: "Times New Roman", Times, serif' id="statusmessage2" class="statusmessage"> yo2</p>
                
            </div>
        </div>
        <?php
            require 'auth.php';        
            $username = $_SESSION["username"];
            $window = $_COOKIE["window"];
            $home = $_GET["home"];
                if ($home === Home){
                    header("Location: home.php");
                    exit;
                }
            $overview = $_GET["overview"];
                if ($overview === Overview){
                    header("Location: overview.php");
                    exit;
                }
            $addvisit = $_GET["addvisit"];
                if ($addvisit === AddVisit){
                    header("Location: addvisit.php");
                    exit;
                }
            $report = $_GET["report"];
                if ($report === Report){
                    header("Location: report.php");
                    exit;
                }
            $settings = $_GET["settings"];
                if ($settings === Settings){
                    header("Location: settings.php");
                    exit;
                }
            $logout = $_GET["logout"];
                if ($logout === Logout){
                    session_destroy();
                    header("Location: index.php");
                    exit;
                }
            echo "<script language='javascript'>  get_name('$username') </script>";
            require "connect.php";
            $infections = [];
            //echo "<script language='javascript'>  alert('$window') </script>";
            $window = $_COOKIE["window"];
            $windownumofdays = ((int)$window) * 7;
            $url = "http://ml-lab-7b3a1aae-e63e-46ec-90c4-4e430b434198.ukwest.cloudapp.azure.com:60999/infections?ts=" . $window;
            //$url = "http://ml-lab-4d78f073-aa49-4f0e-bce2-31e5254052c7.ukwest.cloudapp.azure.com:57188/infections_mock.php?ts=" . $window;
            curl_setopt($handle, CURLOPT_URL, $url);
            curl_setopt($handle, CURLOPT_HTTPGET, true);
            curl_setopt($handle, CURLOPT_HEADER, false);
            if (($output = curl_exec($handle))!==false){
                $infections = json_decode($output, true);
                //echo "<script language='javascript'>  alert('$infections[0]') </script>";
                foreach ($infections as $infection){
                    $xtemp = $infection["x"];
                    $ytemp = $infection["y"];
                    $datetemp = $infection["date"];
                    $timetemp = $infection["time"];
                    $durationtemp = $infection["duration"];
                    //compare the location of the visit of the infected person to all visits of the current user
                    //check for distance (euclidian distance between 2 points use formula) and distance from cookie
                    echo "<script language='javascript'> addmarkerblack('$xtemp', '$ytemp') </script>";
                }
                    $euclidiandistance = (int)$_COOKIE["distance"];
                    $timewindow = 7 * (int)$_COOKIE["window"];

                    $sql = "SELECT Visits.x, Visits.y FROM
                    Accounts INNER JOIN Infections ON Accounts.username = Infections.user
                    INNER JOIN Visits ON Accounts.username = Visits.username
                    WHERE Visits.date BETWEEN DATE_SUB(CURDATE(), INTERVAL '" . $username . "' DAY) AND CURDATE()
                    AND EXISTS
                    (
                     SELECT * FROM Visits V
                     WHERE V.username = '" . $username . "'
                     AND SQRT (POWER(V.x - Visits.x, 2) + POWER(V.y - Visits.y, 2)) < '" . $username . "'
                     AND (Visits.date BETWEEN V.date AND DATE_ADD(V.date, INTERVAL V.duration MINUTE)
                     OR (V.date BETWEEN Visits.date AND DATE_ADD(Visits.date, INTERVAL Visits.duration MINUTE)))
                    )";
                    if (($result=mysqli_query($conn, $sql)) === false)
                        die("Error executing " . $sql);            
                    if (mysqli_num_rows($result) > 0){
                        while($row = mysqli_fetch_assoc($result)) {
                            $xred = $row["Visits.x"];
                            $yred = $row["Visits.y"];
                            echo "<script language='javascript'> addmarkerred('$xred', '$yred') </script>";
                        }
                    }
                    //echo "<script language='javascript'>  alert('$xtemp' + ' ' + '$ytemp' + '$datetemp' + ' ' + '$timetemp' + ' ' + '$durationtemp') </script>";
                
            }
            else{
                $errorvariable = curl_error($handle);
                echo "<script language='javascript'>  alert('$errorvariable') </script>";
            }
            //echo "<script language='javascript'>  alert('test') </script>";

        ?>
    </body>
</html>