


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="index1.css">
    </head>
    <body class="main-T">
        <div class="div-1">COVID - 19 Contact Tracing</div>
        <div class="logincontainer">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
            <input class="input-T" type="text" id="username" name="username" value="Username" required><br><br>
            <input class="input-T" type="text" id="password" name="password" value="Password" required><br><br>
            <input class="login" type="submit" name="login" value="<?=Login?>">
            <input class="cancel" type="submit" value="<?=Cancel?>"><br><br>
            <input class="input-T" type="submit" name="register" value="<?=Register?>">
            </form>
        </div>
        <?php
            require 'auth.php';          
            session_destroy();
            $register = $_GET["register"];
                if ($register === Register){
                    header("Location: register.php");
                    exit;
                }
            $login = $_GET["login"];
                if ($login === Login){
                    $username = $_GET["username"];
                    $password = $_GET["password"];
                    $conn = mysqli_connect(host, user, password, database, port);
                    if (!$conn){
                        die("Connection error: " . mysqli_connect_error());
                    }
                    $sql = "SELECT password from Accounts WHERE username = '" . $username . "'";
                    if (($result=mysqli_query($conn, $sql)) === false)
                        die("Error executing " . $sql);
                    
                    if (mysqli_num_rows($result)!==1)
                        die("Username does not exist");

                    $user=mysqli_fetch_row($result);
                    if (password_verify($password, $user[0])){
                        session_start();
                        $_SESSION["username"] = $username;
                        setcookie("window", "2");
                        setcookie("distance", "100");
                        header("Location: home.php");
                        exit;
                    } else{
                        echo "Wrong password";
                    }
                }
        ?>
    </body>
</html>