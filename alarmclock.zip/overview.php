<?php
    session_start();
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="overview5.css">
        <script type="text/javascript" src="overview2.js"></script>
    </head>
    <script type="text/javascript" src="test.js"></script>
    <body class="main-T"> 
        <div class="div-1">COVID - 19 Contact Tracing</div>
        <div class="first" >
            <div class="menucontainer">
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
                <input class="button" type="submit"  name="home" value="<?=Home?>" ><br>
                <input class="buttoncurrent" type="submit"  name="overview" value="<?=Overview?>" ><br>
                <input class="button" type="submit" name="addvisit" value="<?=AddVisit?>"><br>
                <input class="button" type="submit" name="report" value="<?=Report?>"><br>
                <input class="button" type="submit" name="settings" value="<?=Settings?>"><br><br><br><br>
                <input class="button" type="submit" name="logout" value="<?=Logout?>">
                </form>
            </div>
            <div class="div-2">
                <table id="tableofvisits" class="visitstable">
                    <tr style="font-family: Arial, Helvetica, sans-serif" class="visitstable">
                        <th class="visitstable">Date</th>
                        <th class="visitstable">Time</th>
                        <th class="visitstable">Duration</th>
                        <th class="visitstable">X</th>
                        <th class="visitstable">Y</th>
                        <th class="visitstable"> </th>
                    </tr>
                </table>
            </div>
        </div>
        <script> 
            filltable(); 
        </script>
        <?php
            require 'auth.php';          
            
            $home = $_GET["home"];
                if ($home === Home){
                    header("Location: home.php");
                    exit;
                }
            $overview = $_GET["overview"];
                if ($overview === Overview){
                    header("Location: overview.php");
                    exit;
                }
            $addvisit = $_GET["addvisit"];
                if ($addvisit === AddVisit){
                    header("Location: addvisit.php");
                    exit;
                }
            $report = $_GET["report"];
                if ($report === Report){
                    header("Location: report.php");
                    exit;
                }
            $settings = $_GET["settings"];
                if ($settings === Settings){
                    header("Location: settings.php");
                    exit;
                }
            $logout = $_GET["logout"];
                if ($logout === Logout){
                    header("Location: index.php");
                    exit;
                }
        ?>
    </body>
</html>