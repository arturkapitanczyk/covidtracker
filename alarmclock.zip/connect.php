<?php

if (($handle = curl_init())===false){
    echo 'Curl-Error: ' . curl_error($handle);
    echo "<script language='javascript'>  alert('cant get to connect.php') </script>";
}else{
    curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($handle, CURLOPT_FAILONERROR, true);
}

?>