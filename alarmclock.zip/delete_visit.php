<?php
    
    $row_number = $_POST["rnumber"];
    echo $row_number;
    require 'auth.php'; 
    $conn = mysqli_connect(host, user, password, database, port);
    if (!$conn){
        die("Connection error: " . mysqli_connect_error());
    }
    $sql = "DELETE FROM Visits WHERE id = '" . $row_number . "'";
    if (mysqli_query($conn, $sql)===false){
        die("Error2".$sql);
    }
?>