<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="register1.css">
    </head>
    <body class="main-T">
        <div class="div-1">COVID - 19 Contact Tracing</div>
        <div class="logincontainer">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
            <input class="input-T" type="text" id="name" name="name" value="Name" required><br><br>
            <input class="input-T" type="text" id="surname" name="surname" value="Surname" required><br><br>
            <input class="input-T" type="text" id="username" name="username" value="Username" required><br><br>
            <input class="input-T" type="text" id="password" name="password" value="Password" required><br><br>
            <input class="input-T" type="submit" name="register" value="<?=Register?>">
            </form>
        </div>
        <?php
            require 'auth.php';          
            $register = $_GET["register"];
                if ($register === Register){
                    $conn = mysqli_connect(host, user, password, database, port);
                    if (!$conn){
                        die("Connection error: " . mysqli_connect_error());
                    }
                    $name = $_GET["name"];
                    $surname = $_GET["surname"];
                    $username = $_GET["username"];
                    $password = $_GET["password"];

                    $options = [
                        'cost' => 12,
                    ];

                    $passwd=password_hash($password, PASSWORD_BCRYPT, $options);
                    $sqlcheck = "SELECT password from Accounts WHERE username = '" . $username . "'";
                    if (($result=mysqli_query($conn, $sqlcheck)) === false)
                        die("Error executing " . $sqlcheck);
                    
                    if (mysqli_num_rows($result)!==1){
                        $sql = "INSERT INTO Accounts (name, surname, username, password) VALUES ('" . $name . "', '" . $surname . "', '" . $username . "', '" . $passwd . "')";
                        if (mysqli_query($conn, $sql)===false){
                            die("Error2".$sql);
                        }
                        header("Location: index.php");
                        exit;
                    }else {
                        echo "Username in use";
                    }
                    
                    
                }
            $conn = mysqli_connect(host, user, password, database, port);
            if (!$conn){
                die("Connection error: " . mysqli_connect_error());
            }
        ?>
    </body>
</html>