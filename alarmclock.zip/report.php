<?php
    session_start();
?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="report1.css">
    </head>
    <body class="main-T">
        <div class="div-1">COVID - 19 Contact Tracing</div>
        <div class="first" >
            <div class="menucontainer">
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
                <input class="button" type="submit"  name="home" value="<?=Home?>" ><br>
                <input class="button" type="submit"  name="overview" value="<?=Overview?>" ><br>
                <input class="button" type="submit" name="addvisit" value="<?=AddVisit?>"><br>
                <input class="buttoncurrent" type="submit" name="report" value="<?=Report?>"><br>
                <input class="button" type="submit" name="settings" value="<?=Settings?>"><br><br><br><br>
                <input class="button" type="submit" name="logout" value="<?=Logout?>">
                </form>
            </div>
            <div class="div-2">
                <h2>Report an Infection</h2>
                <hr>
                <p> Please report the date and time you tested positive for COVID-19.</p>
                <br><br><br><br><br><br><br><br>
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
                <input class="input-T" type="text"  name="date" value="Date" ><br><br>
                <input class="input-T" type="text"  name="time" value="Time" ><br><br>
                <input class="input-T" type="submit" name="reportdata" value="<?=Report?>">
                <input class="input-T" type="submit" name="cancel" value="<?=Cancel?>">
                </form>
                
                
            </div>
        <?php
            require 'auth.php';          

            $home = $_GET["home"];
                if ($home === Home){
                    header("Location: home.php");
                    exit;
                }
            $overview = $_GET["overview"];
                if ($overview === Overview){
                    header("Location: overview.php");
                    exit;
                }
            $addvisit = $_GET["addvisit"];
                if ($addvisit === AddVisit){
                    header("Location: addvisit.php");
                    exit;
                }
            $report = $_GET["report"];
                if ($report === Report){
                    header("Location: report.php");
                    exit;
                }
            $settings = $_GET["settings"];
                if ($settings === Settings){
                    header("Location: settings.php");
                    exit;
                }
            $logout = $_GET["logout"];
                if ($logout === Logout){
                    header("Location: index.php");
                    exit;
                }
            $reportdata = $_GET["reportdata"];
                if ($reportdata === Report){
                    $date = $_GET["date"];
                    $time = $_GET["time"];
                    $username = $_SESSION["username"];
                    $iscorrectentry = True;
                    if(!DateTime::createFromFormat('Y-m-d', $date)){
                        $iscorrectentry = False;
                        exit;
                    }
                    
                    if(!DateTime::createFromFormat('H:i:s', $time)){
                        $iscorrectentry = False;
                        exit;
                    }
                    if($iscorrectentry){
                        $conn = mysqli_connect(host, user, password, database, port);
                        if (!$conn){
                            die("Connection error: " . mysqli_connect_error());
                        }

                        $sql = "INSERT INTO Infections (date, time, username) VALUES ('" . $date . "', '" . $time . "', '" . $username . "')";
                        if (mysqli_query($conn, $sql)===false){
                            die("Error2".$sql);
                        }
                        //make a report to api
                        $infections = [];
                        $url = "http://ml-lab-7b3a1aae-e63e-46ec-90c4-4e430b434198.ukwest.cloudapp.azure.com:60999/report";
                        //$url = "http://ml-lab-4d78f073-aa49-4f0e-bce2-31e5254052c7.ukwest.cloudapp.azure.com:57188/report_mock.php";
                        $visitsofuser = "SELECT date, time, duration, x, y, id from Visits WHERE username = '" . $username . "'";
                        if (($result=mysqli_query($conn, $visitsofuser)) === false)
                            die("Error executing " . $visitsofuser);            
                        if (mysqli_num_rows($result) > 0){
                            while($row = mysqli_fetch_assoc($result)) {
                                array_push($infections, array("x"->$row["x"], "y"->$row["y"], "date"->$row["date"], "time"->$row["time"], "duration"->$row["duration"]));
                            }
                            //echo "<script language='javascript'>  alert('yo') </script>";
                            foreach($infections as $infection){
                                //echo "<script language='javascript'>  alert('infection') </script>";
                                require "connect.php";
                                curl_setopt($handle, CURLOPT_URL, $url);
                                curl_setopt($handle, CURLOPT_HTTPHEADER, array("Content-type: application/json"));
                                curl_setopt($handle, CURLOPT_POSTFIELDS, json_encode($infection));
                                curl_exec($handle);
                                //echo "<script language='javascript'>  alert('$tempcode') </script>";
                            }
                        }
                        

                        exit;
                    }
                    else{
                        Header("Location: report.php");
                        exit;
                    }

                }
            $cancel = $_GET["cancel"];
                if ($cancel === Cancel){
                    Header("Location: report.php");
                    exit;
                }

        ?>
    </body>
</html>