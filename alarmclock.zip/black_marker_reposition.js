function react_to_marker_click(){
    var map = document.getElementById("exetermap");
    map.addEventListener('click', function(event){
        coordinatesofmap = this.getBoundingClientRect();
        var x = event.clientX - coordinatesofmap.left;
        var y = coordinatesofmap.bottom - event.clientY;
        xinput = document.getElementById("x");
        yinput = document.getElementById("y");

        xinput.value = Math.round(x);
        yinput.value = Math.round(y);
        //alert(Math.round(x) + " " + Math.round(y));

        var marker = document.getElementById("blackmarker");
        marker.style.left = '' + (event.clientX - 25) + 'px';
        marker.style.top = '' + event.clientY - 50 + 'px';



    });
}