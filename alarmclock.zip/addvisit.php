<?php
    session_start();
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="addvisit9.css">
        <script type="text/javascript" src="black_marker_reposition.js"></script>
    </head>
    <body class="main-T">
        <div class="div-1">COVID - 19 Contact Tracing</div>
        <div class="first" >
            <div class="menucontainer">
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
                <input class="button" type="submit"  name="home" value="<?=Home?>" ><br>
                <input class="button" type="submit"  name="overview" value="<?=Overview?>" ><br>
                <input class="buttoncurrent" type="submit" name="addvisit" value="<?=AddVisit?>"><br>
                <input class="button" type="submit" name="report" value="<?=Report?>"><br>
                <input class="button" type="submit" name="settings" value="<?=Settings?>"><br><br><br><br>
                <input class="button" type="submit" name="logout" value="<?=Logout?>">
                </form>
            </div>
            <div class="div-2">
                <h2>Add a new Visit</h2>
                <hr>
                <img class="exetermap" src="exetermap.jpg" align="right" id="exetermap">
                <img class="blackmarker" src="marker_black.png" align="right" id="blackmarker">
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
                <input class="input-T" type="text" id="date" name="date" value="Date" required><br><br>
                <input class="input-T" type="text" id="time" name="time" value="Time" required><br><br>
                <input class="input-T" type="text" id="duration" name="duration" value="Duration" required><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                <input type="hidden" id="x" name="x" value="0" required>
                <input type="hidden" id="y" name="y" value="0" required>
                <input class="input-T" type="submit" name="add" value="<?=Add?>"><br><br>
                <input class="input-T" type="submit" name="cancel" value="<?=Cancel?>">
                </form>
            </div>
        </div>
        <script>
            react_to_marker_click();
        </script>
        <?php
            require 'auth.php';          

            $home = $_GET["home"];
                if ($home === Home){
                    header("Location: home.php");
                    exit;
                }
            $overview = $_GET["overview"];
                if ($overview === Overview){
                    header("Location: overview.php");
                    exit;
                }
            $addvisit = $_GET["addvisit"];
                if ($addvisit === AddVisit){
                    header("Location: addvisit.php");
                    exit;
                }
            $report = $_GET["report"];
                if ($report === Report){
                    header("Location: report.php");
                    exit;
                }
            $settings = $_GET["settings"];
                if ($settings === Settings){
                    header("Location: settings.php");
                    exit;
                }
            $logout = $_GET["logout"];
                if ($logout === Logout){
                    header("Location: index.php");
                    exit;
                }
            $add = $_GET["add"];
                if ($add === Add){
                    $date = $_GET["date"];
                    $time = $_GET["time"];
                    $duration = $_GET["duration"];
                    $x = $_GET["x"];
                    $y = $_GET["y"];
                    $iscorrectentry = True;
                    if(!DateTime::createFromFormat('Y-m-d', $date)){
                        $iscorrectentry = False;
                        exit;
                    }
                    
                    if(!DateTime::createFromFormat('H:i:s', $time)){
                        $iscorrectentry = False;
                        exit;
                    }

                    if(!is_numeric($duration)){
                        $iscorrectentry = False;
                        exit;
                    }
                    
                    if($iscorrectentry){
                        $conn = mysqli_connect(host, user, password, database, port);
                        if (!$conn){
                            die("Connection error: " . mysqli_connect_error());
                        }

                        $numberofrowsquery = "SELECT count(*) from Visits";
                        if (($numberofrowsarray=mysqli_query($conn, $numberofrowsquery)) === false){
                            die("Error2".$numberofrowsquery);
                        }
                        $numberofrows = mysqli_fetch_array($numberofrowsarray);
                        $numberofrowsfinal = $numberofrows[0];
                        $numberofrowsfinal = $numberofrowsfinal + 1;

                        
                        $isuniquenewid = FALSE;
                        while (!$isuniquenewid){
                            $uniqueidquery = "SELECT id from Visits WHERE id = '" . $numberofrowsfinal . "'";
                            if (($result=mysqli_query($conn, $uniqueidquery)) === false)
                                $numberofrowsfinal = $numberofrowsfinal + 1;
                            else{
                                $isuniquenewid = TRUE;
                            }
                        }

                        $username = $_SESSION["username"];

                        $sql = "INSERT INTO Visits (date, time, duration, x, y, id, username) VALUES ('" . $date . "', '" . $time . "', '" . $duration . "', '" . $x . "', '" . $y . "', '" . $numberofrowsfinal . "', '" . $username . "')";
                        if (mysqli_query($conn, $sql)===false){
                            die("Error2".$sql);
                        }
                        exit;
                    }
                    

                }
            $cancel = $_GET["cancel"];
                if($cancel === Cancel){
                    header("Location: addvisit.php");
                    exit;
                }
        ?>
    </body>
</html>